# Browserless Starter-pack
This simple starter-pack gets you up and running with all the code you used in the debugger. Just install and run!

## Requirements
- NodeJS (version 12 or higher).
- An environment to run command's (Terminal or others).

## Running
1. NodeJS >= 12 is installed
2. 'npm install'
3. 'npm start'
